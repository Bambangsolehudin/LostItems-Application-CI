<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('menu_model');
	}
	public function index()
	{
		$data['sum'] = $this->menu_model->get_sum();
		$data['sum1'] = $this->menu_model->get_sum1();
		$data['sum2'] = $this->menu_model->get_sum2();
		$data['nama'] = $this->menu_model->countNama();
		$data['nilai'] = $this->db->get('nilai')->result_array();
		$this->load->view('table',$data);
	}
	
	public function table()
	{
		$data['nilai'] = $this->db->get('nilai')->result_array();
		
		$this->form_validation->set_rules('npm','NPM','required');
		$this->form_validation->set_rules('nama','Nama','required');
		$this->form_validation->set_rules('p_web','p_web','required');
		$this->form_validation->set_rules('jarlan','jarlan','required');
		$this->form_validation->set_rules('t_kompilasi','t_kompilasi','required');
		
		if ($this->form_validation->run() == false) 
		{	
			$this->load->view('table',$data);
		}else{

			$npm = strtoupper($this->input->post('npm'));
			$nama = strtoupper($this->input->post('nama'));
			$p_web = strtoupper($this->input->post('p_web'));
			$jarlan = strtoupper($this->input->post('jarlan'));
			$t_kompilasi = strtoupper($this->input->post('t_kompilasi'));

		$data =
			[
				'npm' => $npm,
				'nama' => $nama,
				'p_web' => $p_web,
				'jarlan' => $jarlan,
				't_kompilasi'=> $t_kompilasi
			];

		$this->db->insert('nilai', $data);
		$this->session->set_flashdata('message','<div class="alert alert-success" role="alert">
				Data Baru di Tambahkan!
				</div>');
		redirect('welcome/index');
	}
	}

	public function delete($id) {
		$this->db->where('id',$id);
		$this->db->delete('nilai');
		$this->session->set_flashdata('message','<div class="alert alert-success" role="alert">
			Data dihapus!
			</div>');
		redirect(base_url());
	}

	public function edit($id)
	{
		$data['nilai'] = $this->db->get('nilai')->result_array();
		$data['edit'] = $this->menu_model->getNilaiById($id);
		$this->load->view('edit_nilai',$data);
		
	}

	public function update($id) {
			$npm = strtoupper($this->input->post('npm'));
			$nama = strtoupper($this->input->post('nama'));
			$p_web = strtoupper($this->input->post('p_web'));
			$jarlan = strtoupper($this->input->post('jarlan'));
			$t_kompilasi = strtoupper($this->input->post('t_kompilasi'));

			$data =
			[
				'npm' => $npm,
				'nama' => $nama,
				'p_web' => $p_web,
				'jarlan'=> $jarlan,
				't_kompilasi'=> $t_kompilasi
			];
			$this->db->where('id',$id);
			$this->db->update('nilai',$data);
			$this->session->set_flashdata('message','<div class="alert alert-success" role="alert">
				Data diperbarui!
				</div>');
			redirect(base_url());
	}
}
