<?php  
 
defined('BASEPATH') or exit('No direct script access allowed');
class menu_model extends CI_model
{

	public function get_sum()
	{
		$sql = "SELECT SUM(p_web) as p_web from nilai";
		$result = $this->db->query($sql);
		return $result->row()->p_web;
	}

	public function get_sum1()
	{
		$sql = "SELECT SUM(jarlan) as jarlan from nilai";
		$result = $this->db->query($sql);
		return $result->row()->jarlan;
	}

	public function get_sum2()
	{
		$sql = "SELECT SUM(t_kompilasi) as t_kompilasi from nilai";
		$result = $this->db->query($sql);
		return $result->row()->t_kompilasi;
	}
	public function countNama()
	{
		$sql = "SELECT COUNT(nama) as nama from nilai";
		$result = $this->db->query($sql);
		return $result->row()->nama;
	}

	public function getNilaiById($id)
	{
		return $this->db->get_where('nilai', ['id' => $id ])->row_array();
	}


}